---
name: ForgePilot Industrial Enterprise
colors:
  surface: '#f6f9ff'
  surface-dim: '#d3dbe4'
  surface-bright: '#f6f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf4fe'
  surface-container: '#e7eff8'
  surface-container-high: '#e1e9f2'
  surface-container-highest: '#dbe3ed'
  on-surface: '#151c23'
  on-surface-variant: '#42474f'
  inverse-surface: '#293138'
  inverse-on-surface: '#eaf1fb'
  outline: '#727780'
  outline-variant: '#c2c7d1'
  surface-tint: '#2d6197'
  primary: '#00355f'
  on-primary: '#ffffff'
  primary-container: '#0f4c81'
  on-primary-container: '#8ebdf9'
  inverse-primary: '#a0c9ff'
  secondary: '#465f88'
  on-secondary: '#ffffff'
  secondary-container: '#b6d0ff'
  on-secondary-container: '#3f5881'
  tertiary: '#003561'
  on-tertiary: '#ffffff'
  tertiary-container: '#004c87'
  on-tertiary-container: '#8abdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#a0c9ff'
  on-primary-fixed: '#001c37'
  on-primary-fixed-variant: '#07497d'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#aec7f7'
  on-secondary-fixed: '#001b3d'
  on-secondary-fixed-variant: '#2e476f'
  tertiary-fixed: '#d3e4ff'
  tertiary-fixed-dim: '#a2c9ff'
  on-tertiary-fixed: '#001c38'
  on-tertiary-fixed-variant: '#004881'
  background: '#f6f9ff'
  on-background: '#151c23'
  surface-variant: '#dbe3ed'
typography:
  display:
    fontFamily: Noto Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-semibold:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption-sm:
    fontFamily: Noto Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  caption-strong:
    fontFamily: Noto Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  code-tabular:
    fontFamily: Noto Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system establishes a high-density, mission-critical environment tailored for industrial equipment predictive maintenance, asset diagnostics, and telemetry analysis. The target audience comprises plant operations directors, reliability engineers, and field technicians working in desktop-first industrial operating centres. 

The aesthetic is anchored strictly in the Microsoft Fluent 2 Web design language: disciplined, structured, and audit-ready. The interface rejects consumer-software decorative tropes—eliminating gratuitous gradients, AI-glow accents, neon backlights, and glassmorphism. Visual authority is achieved through structural alignment, clear typographic hierarchy, exact 1px architectural dividers, and functional state styling that ensures zero ambiguity in high-consequence operational decisions.

## Colors

The system uses a calibrated palette reflecting industrial precision:
- **Primary Canvas Background**: `#F5F6F8` (cool industrial tint) to reduce eye fatigue during prolonged shift rotations.
- **Surface / Card Background**: Pure `#FFFFFF`, creating sharp functional contrast against the canvas.
- **Brand Accents**: Primary `#0F4C81` (Classic Steel Blue), Secondary `#1B365D` (Deep Naval Steel for navigational hierarchy and critical commands), and Tertiary `#005A9E` (Fluent Active Interactive Blue).
- **Neutral Outlines**: Structural borders rely strictly on `#E5E7EB` (subtle inner separators) and `#D1D5DB` (control outlines and surface definitions).

### Semantic & Telemetry Status Palette
Colors carry operational semantics only and must never be applied decoratively:
- **Operational / Normal**: `#107C41` (Fluent Solid Forest Green)
- **Warning / Degraded Condition**: `#D83B01` (Safety Amber) and `#C19C00` (Caution Ochre)
- **Critical / Fault / Emergency Stop**: `#A80000` (Hazard Crimson) and `#D13438` (Active Alert Red)
- **Informational / Sync State**: `#0078D4` (Telemetry Sync Blue)

## Typography

The font stack prioritizes regional enterprise legibility: `Segoe UI, "Microsoft YaHei", "PingFang SC", "Noto Sans SC", sans-serif`. 

- **Density & Scale**: Standard dense desktop reading is fixed at 14px body text (`body-md`) with a strict 20px line height. Auxiliary parameters, audit log timestamps, and metadata leverage 12px (`caption-sm`). Page and module titles range between 20px and 24px (`headline-md` to `headline-lg`), avoiding excessive hero sizing.
- **Tabular Figures**: Sensor readouts, vibration frequencies, rotational speeds (RPM), and fault codes must enable tabular lining numbers (`font-variant-numeric: tabular-nums`) to prevent optical jittering during real-time telemetry refreshes.
- **Button Constraints**: Label text in interactive buttons is strictly single-line, center-aligned, with explicit truncation ellipsis rules when bound to localized dynamic content.

## Layout & Spacing

The layout is built around a compact, high-utility fluid desktop workstation architecture designed for wide monitors (1440px to 1920px+):

- **Column System**: 12-column dynamic fluid grid utilizing 16px (`1rem`) gutters and a fixed 24px (`1.5rem`) canvas edge margin.
- **Structure**:
  - Global Command Rail (Side Navigation): Fixed 48px collapsed or 240px expanded navigation panel.
  - Workspace Context Header: Fixed 48px height for breadcrumbs, telemetry filter presets, and profile actions.
  - Split-pane Telemetry Docking: Configurable 60/40 or 70/30 layout dividing industrial schematics/time-series charts from alarm resolution sheets.
- **Rhythm**: Spacing enforces an 8pt base grid with a 4pt sub-grid for internal component padding. Form field heights default to 32px (compact) or 36px (standard).

## Elevation & Depth

In adherence to Fluent 2 Web engineering principles, depth is communicated primarily through structural framing and conservative ambient occlusion rather than heavy drop shadows:

- **Surface Layering**:
  - **Level 0 (App Canvas)**: `#F5F6F8` flat base.
  - **Level 1 (Card & Container Workspaces)**: `#FFFFFF` surfaced with a mandatory 1px border (`#E5E7EB`).
  - **Level 2 (Hovered & Active Elements)**: `#FFFFFF` with a crisp 1px border (`#D1D5DB`) and minimal ambient lift (`box-shadow: 0 1.6px 3.6px 0 rgba(0, 0, 0, 0.08), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.04)`).
  - **Level 3 (Flyouts, Popovers & Dropdowns)**: Elevated above content (`box-shadow: 0 6.4px 14.4px 0 rgba(0, 0, 0, 0.12), 0 1.2px 3.6px 0 rgba(0, 0, 0, 0.08)`).
  - **Level 4 (Audit Modals & Emergency Confirmation Dialogs)**: High-priority overlay paired with a solid `#000000` 32% opacity scrim.
- **Outline Discipline**: Outlines remain crisp and unblurred. Form components in their resting state maintain a 1px border in `#D1D5DB`, switching on focus to a distinct 2px solid `#0F4C81` outline with an explicit 1px white separation offset.

## Shapes

The shape system is controlled, functional, and geometric. It adheres to an enterprise radius scale:

- **Controls (Buttons, Inputs, Selects, Checkboxes)**: Standardized at 4px to 6px corner radius.
- **Containers (Cards, Side Drawers, Modals)**: Standardized at 6px to 8px corner radius.
- **Status Badges & Tag Counters**: Controlled 4px radius or 12px pill geometry strictly when representing count badges.
- Large circular cards, fluid asymmetry, and decorative amorphous shapes are strictly prohibited.

## Components

### Buttons
- **Primary**: Solid `#0F4C81` fill with `#FFFFFF` text. Hover state shifts to `#1B365D`. Pressed state shifts to `#0A2B4C` with a subtle inset transform (`scale(0.98)`).
- **Secondary / Standard**: `#FFFFFF` background with 1px `#D1D5DB` border and `#1B365D` text. Hover shifts background to `#F0F2F5`.
- **Destructive**: `#FFFFFF` background with 1px `#D13438` border and `#D13438` text. Active/Primary destructive uses solid `#A80000` with white text.
- **Dimensions**: Desktop default height 32px (small) and 36px (medium). Padding horizontal 12px to 16px. Single-line text only.

### Input Fields & Selects
- Height 32px/36px. Pure `#FFFFFF` background with 1px bottom accent indicator or full 1px `#D1D5DB` border.
- Hover: Border darkens to `#8A8886`.
- Focus: 2px solid `#0F4C81` with sharp edge rendering.
- Labels: Always top-aligned or left-aligned, set in 12px bold (`caption-strong`) `#5A626A`. Never use placeholders as replacement labels.

### Checkboxes & Radio Buttons
- 16px × 16px square (checkbox: 3px radius) and circle (radio).
- 1px neutral stroke `#5A626A`. Checked state fills `#0F4C81` with white checkmark icon. High-contrast border ensures legibility against both white cards and gray canvas backgrounds.

### Status Indicators & Badges (Industrial Telemetry)
- Composed of an 8px circular status dot and an accompanying text label.
- Normal: Dot `#107C41`, background tint `#E8F5E9` (10% tint).
- Warning: Dot `#D83B01`, background tint `#FFF4E5`.
- Critical Alert: Dot `#D13438`, background tint `#FDE7E9`.

### Data Cards & Diagnostics Panels
- Container: `#FFFFFF` fill, 1px `#E5E7EB` border, 6px radius.
- Header: 40px height with 1px `#E5E7EB` bottom divider, containing module title (`headline-sm`) and contextual actions (e.g., Export, Refresh interval, Filter).
- Body: 16px uniform padding.

### Data Grid (Equipment Log & Work Orders)
- Dense layout with 36px row height.
- Header row: `#F0F2F5` background, uppercase 12px semibold text, 1px bottom border `#D1D5DB`.
- Row hover: `#F8F9FA`. Alternating zebra rows avoided in favor of crisp 1px horizontal cell dividers (`#F0F2F5`).